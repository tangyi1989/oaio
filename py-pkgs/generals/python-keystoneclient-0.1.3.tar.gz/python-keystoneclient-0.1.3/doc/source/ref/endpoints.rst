==============================
Endpoint Manager and Endpoints
==============================



.. currentmodule:: keystoneclient.v2_0.endpoints

.. automodule:: keystoneclient.v2_0.endpoints
    :members:

