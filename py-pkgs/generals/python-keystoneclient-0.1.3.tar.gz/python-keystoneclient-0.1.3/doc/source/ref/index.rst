API Reference
=============

The following API reference documents are available:

.. toctree::
   :maxdepth: 1

   client
   generic-client
   tenants
   users
   roles
   services
   endpoints
   exceptions
