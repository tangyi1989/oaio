Generic client
==============

Use the generic client to obtain access to a specific endpoint version.


.. currentmodule:: keystoneclient.generic.client

.. autoclass:: Client

    .. automethod:: discover

