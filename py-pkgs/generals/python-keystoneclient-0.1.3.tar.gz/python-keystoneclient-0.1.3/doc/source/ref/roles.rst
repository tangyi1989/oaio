======================
Role Manager and Roles
======================

.. currentmodule:: keystoneclient.v2_0.roles

.. automodule:: keystoneclient.v2_0.roles
    :members:

