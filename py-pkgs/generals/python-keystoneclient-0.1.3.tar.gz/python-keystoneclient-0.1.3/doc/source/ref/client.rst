Client
======

.. currentmodule:: keystoneclient.v2_0.client

.. autoclass:: Client

    .. automethod:: authenticate
