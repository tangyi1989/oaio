======================
User Manager and Users
======================

.. currentmodule:: keystoneclient.v2_0.users

.. automodule:: keystoneclient.v2_0.users
    :members:

