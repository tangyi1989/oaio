============================
Service Manager and Services
============================



.. currentmodule:: keystoneclient.v2_0.services

.. automodule:: keystoneclient.v2_0.services
    :members:

