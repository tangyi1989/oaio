==========================
Tenant Manager and Tenants
==========================



.. currentmodule:: keystoneclient.v2_0.tenants

.. automodule:: keystoneclient.v2_0.tenants
    :members:

